<?php

return [
    'hello' => 'ওহে বিশ্ব!',
    'laravel' => 'লারাভেল',
    'login' => 'প্রবেশ করুন',
    'register' => 'নিবন্ধন করুন',

];
