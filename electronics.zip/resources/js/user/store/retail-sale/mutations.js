export default {
    initWarehouses: (state, data) => {
        state.warehouses = data;
    }
};
