const state = () => ({
    selectedProducts: []
});

export default state;
