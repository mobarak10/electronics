export default {
    activeCategories: [],
    activeProducts: [],
    cartProducts: [],
    cartSubTotal: null,
    productFilter: {},
    filteredProductsFromServer: [], // fetch from server,
    productsIsLoading: false,
    temp: {
        // temp state
        searchProduct: null // current value of search product
    }
};
